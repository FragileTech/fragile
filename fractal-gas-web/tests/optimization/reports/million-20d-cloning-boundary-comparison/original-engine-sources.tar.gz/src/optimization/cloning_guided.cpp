#include "optimization/cloning_guided.hpp"
#include "optimization/adaptive.hpp"
#include <Eigen/Dense>
#include <algorithm>
#include <map>
#include <set>
#include <numeric>

namespace fg::optimization {
namespace {
using Mat=Eigen::MatrixXd;
using Vec=Eigen::VectorXd;
void str(Json& j,const char* key,const std::string& value) {j.object[key].kind=Json::String;j.object[key].string=value;}
}
struct CloningGuided::Impl {
  struct Model { std::vector<float> anchor;Mat shape,factor;Vec drift;size_t families=0;double condition=1; };
  int d;double width,low=.0001,high=1,upper=1,strength=.25;
  bool periodic=false,minimize=true,geometry_enabled=true,drift_enabled=true,dirty=false,expected=true;
  std::string mode="velocity";
  uint64_t version=0;
  size_t fallback=0;
  fractal::FrozenPopulation pending;
  fractal::SelectionEvidence evidence;
  std::vector<double> ranks;
  std::vector<Model> models;
  Impl(const Benchmark& b):d(b.d),width(b.high-b.low) {}
  Vec offset(const float* x,const float* anchor) const {
    Vec y(d);for(int j=0;j<d;++j) {double v=double(x[j])-anchor[j];if(periodic) v=std::remainder(v,width);y[j]=v/width;}return y;
  }
  size_t nearest(const float* x) const {
    size_t best=0;double distance=INFINITY;
    for(size_t i=0;i<models.size();++i) {double v=offset(x,models[i].anchor.data()).squaredNorm();if(v<distance) {distance=v;best=i;}}
    return best;
  }
  Model fresh(const float* x) const {
    Model m;m.anchor.assign(x,x+d);m.drift=Vec::Zero(d);
    if(d<=64) {m.shape=Mat::Identity(d,d);m.factor=m.shape;}else m.shape=Mat::Ones(d,1);
    return m;
  }
  double scale(double value) const {
    double p=.5;
    if(std::isfinite(value)&&ranks.size()>1&&ranks.front()!=ranks.back()) {
      double cost=minimize?value:-value;
      p=std::clamp((double(std::lower_bound(ranks.begin(),ranks.end(),cost)-ranks.begin())+
          double(std::upper_bound(ranks.begin(),ranks.end(),cost)-ranks.begin())-1)/(2*(ranks.size()-1)),0.,1.);
    }
    return low>0?std::exp((1-p)*std::log(low)+p*std::log(upper)):p*upper;
  }
  Vec multiply(const Model& m,const Vec& v) const {
    if(d<=64) return m.shape*v;
    Vec result=m.shape.col(0).array()*v.array();
    if(m.shape.cols()>1) result+=m.shape.rightCols(m.shape.cols()-1)*(m.shape.rightCols(m.shape.cols()-1).transpose()*v);
    return result;
  }
  void draw(const float* x,float* delta,double scale,Rng& rng) const {
    Vec z(d);for(int j=0;j<d;++j) z[j]=normal(rng);
    Vec y=z;
    if(!models.empty()) {
      const auto& m=models[nearest(x)];
      if(geometry_enabled) {
        if(d<=64) y=m.factor*z;
        else {y=m.shape.col(0).array().sqrt()*z.array();for(int k=1;k<m.shape.cols();++k) y+=m.shape.col(k)*normal(rng);}
      }
      if(drift_enabled) y+=m.drift;
    }
    for(int j=0;j<d;++j) delta[j]=float(scale*y[j]);
  }
  void fit(Model& m,const std::vector<size_t>& rows) {
    std::set<uint64_t> families;
    double total=0;Vec mean=Vec::Zero(d);
    for(size_t i:rows) {families.insert(pending.families[i]);total+=evidence.mass[i];mean+=evidence.mass[i]*offset(pending.positions.data()+i*d,m.anchor.data());}
    m.families=families.size();
    if(total<=0||families.size()<4) {++fallback;return;}
    mean/=total;
    Mat x(d,rows.size());
    for(size_t k=0;k<rows.size();++k) {size_t i=rows[k];x.col(k)=std::sqrt(evidence.mass[i]/total)*(offset(pending.positions.data()+i*d,m.anchor.data())-mean);}
    const double trace=x.squaredNorm();
    if(!std::isfinite(trace)||trace<1e-20) {++fallback;return;}
    const double shrink=std::min(1.,double(d)/std::max(1.,double(families.size()-1)));
    if(d<=64) {
      Mat shape=(1-shrink)*double(d)/trace*(x*x.transpose());shape.diagonal().array()+=shrink;
      Eigen::SelfAdjointEigenSolver<Mat> eig(shape);
      if(eig.info()!=Eigen::Success) {++fallback;return;}
      Vec values=eig.eigenvalues().cwiseMax(std::max(1e-12,eig.eigenvalues().maxCoeff()/1e6));
      values*=d/values.sum();m.condition=values.maxCoeff()/values.minCoeff();
      m.shape=eig.eigenvectors()*values.asDiagonal()*eig.eigenvectors().transpose();
      Eigen::LLT<Mat> chol(m.shape);if(chol.info()!=Eigen::Success) {++fallback;m=fresh(m.anchor.data());return;}
      m.factor=chol.matrixL();
    } else {
      // Deterministic block power iteration: never allocate a d-by-d matrix.
      const int rank=std::min<int>(8,std::min(d,int(x.cols())));Mat basis(d,rank);
      for(int j=0;j<d;++j) for(int k=0;k<rank;++k) basis(j,k)=std::sin(double((j+1)*(k+1)));
      for(int k=0;k<12;++k) {Mat next=x*(x.transpose()*basis);Eigen::HouseholderQR<Mat> qr(next);basis=qr.householderQ()*Mat::Identity(d,rank);}
      Mat projected=basis.transpose()*x;Eigen::SelfAdjointEigenSolver<Mat> eig(projected*projected.transpose());
      if(eig.info()!=Eigen::Success) {++fallback;return;}
      Mat components=basis*eig.eigenvectors()*eig.eigenvalues().cwiseMax(0).cwiseSqrt().asDiagonal();
      Vec residual=x.array().square().rowwise().sum().matrix()-components.array().square().rowwise().sum().matrix();
      m.shape.resize(d,rank+1);m.shape.col(0)=((1-shrink)*d/trace*residual.cwiseMax(0).array()+shrink).matrix();
      m.shape.rightCols(rank)=std::sqrt((1-shrink)*d/trace)*components;
      double bound=m.shape.col(0).maxCoeff()+m.shape.rightCols(rank).squaredNorm();
      m.shape.col(0)=m.shape.col(0).cwiseMax(std::max(1e-12,bound/1e6));
      double norm=d/(m.shape.col(0).sum()+m.shape.rightCols(rank).squaredNorm());
      m.shape.col(0)*=norm;m.shape.rightCols(rank)*=std::sqrt(norm);
      m.condition=(m.shape.col(0).maxCoeff()+m.shape.rightCols(rank).squaredNorm())/m.shape.col(0).minCoeff();
    }
    // The regression measures evidence, not density mass. Collapse identical
    // family/location rows; offspring multiplicity cannot manufacture support.
    std::map<std::pair<uint64_t,std::vector<float>>,size_t> unique;
    for(size_t i:rows) if(std::isfinite(evidence.fitness[i])&&evidence.fitness[i]>0) {
      const float* point=pending.positions.data()+i*d;
      unique.emplace(std::make_pair(pending.families[i],std::vector<float>(point,point+d)),i);
    }
    std::set<uint64_t> fit_families;
    for(const auto& entry:unique) fit_families.insert(entry.first.first);
    if(fit_families.size()<4) {++fallback;return;}
    Mat design(d,unique.size());Vec response(unique.size());int k=0;
    for(const auto& entry:unique) {size_t i=entry.second;design.col(k)=offset(pending.positions.data()+i*d,m.anchor.data());response[k++]=std::log(evidence.fitness[i]);}
    design.colwise()-=design.rowwise().mean().eval();response.array()-=response.mean();
    design/=std::sqrt(double(unique.size()));response/=std::sqrt(double(unique.size()));
    double ridge=std::max(1e-12,1e-3*design.squaredNorm()/d);
    Vec rhs=design*response,gradient=Vec::Zero(d),residual=rhs,direction=rhs;
    double rr=residual.squaredNorm();
    for(int it=0;it<std::min(256,2*d)&&rr>1e-20;++it) {
      Vec product=design*(design.transpose()*direction)+ridge*direction;
      double alpha=rr/std::max(1e-30,direction.dot(product));gradient+=alpha*direction;residual-=alpha*product;
      double next=residual.squaredNorm();direction=residual+(next/rr)*direction;rr=next;
    }
    if(!gradient.allFinite()) {++fallback;return;}
    Vec drift=geometry_enabled?multiply(m,gradient):gradient;
    double norm=std::sqrt(std::max(0.,gradient.dot(drift)));
    if(norm>0) drift*=std::min(1.,strength*std::sqrt(double(d))/norm);
    m.drift=drift;
  }
};
CloningGuided::CloningGuided(const Benchmark& b,const Json& c):impl(std::make_unique<Impl>(b)) {configure(c);}
CloningGuided::CloningGuided(const CloningGuided& other):impl(std::make_unique<Impl>(*other.impl)) {}
CloningGuided::~CloningGuided()=default;
void CloningGuided::configure(const Json& c) {
  auto& s=*impl;
  double low=bounded(c["adaptive_min_scale"],.0001,0,1e6,"minimum movement scale");
  double high=bounded(c["adaptive_max_scale"],1,low,1e6,"maximum movement scale");
  double fraction=bounded(c["adaptive_round_fraction"],1,0,1,"round scale fraction");
  bool periodic=c["periodic"].flag(false);auto mode=c["adaptive_euclidean_mode"].str("velocity");
  if(mode!="velocity"&&mode!="position") throw std::invalid_argument("Invalid Euclidean movement mode");
  if(periodic!=s.periodic||mode!=s.mode) reset();
  s.periodic=periodic;s.mode=mode;s.minimize=c["objective"].str("minimize")=="minimize";
  s.low=low;s.high=high;s.upper=low>0?std::exp((1-fraction)*std::log(low)+fraction*std::log(high)):fraction*high;
  const double old_strength=s.strength;const bool old_geometry=s.geometry_enabled;
  s.strength=bounded(c["cloning_drift_strength"],.25,0,1,"cloning drift strength");
  s.geometry_enabled=c["cloning_geometry"].flag(true);s.drift_enabled=c["cloning_drift"].flag(true);
  // Drifts depend on both strength and geometry; invalidate instead of keeping
  // a stale vector after a live setting change. Geometry remains reusable.
  for(auto& m:s.models) {
    if(old_geometry!=s.geometry_enabled || old_strength==0) m.drift.setZero();
    else if(s.strength!=old_strength) m.drift*=s.strength/old_strength;
  }
}
void CloningGuided::freeze_population(const fractal::FrozenPopulation& p) {
  auto& s=*impl;s.ranks.clear();
  for(size_t i=0;i<p.objectives.size();++i) if(p.valid[i]&&std::isfinite(p.objectives[i])) s.ranks.push_back(s.minimize?p.objectives[i]:-p.objectives[i]);
  std::sort(s.ranks.begin(),s.ranks.end());
}
void CloningGuided::observe_cloning(const fractal::FrozenPopulation& p,const fractal::SelectionEvidence& e) {
  const size_t n=p.valid.size();
  if(p.dimensions!=impl->d||p.positions.size()!=n*impl->d||p.families.size()!=n||p.objectives.size()!=n||e.mass.size()!=n||e.fitness.size()!=n) throw std::invalid_argument("Cloning snapshot shape");
  for(double w:e.mass) if(!std::isfinite(w)||w<0) throw std::invalid_argument("Invalid cloning mass");
  impl->pending=p;impl->evidence=e;impl->dirty=true;
}
void CloningGuided::update() {
  auto& s=*impl;if(!s.dirty) return;
  s.models.clear();s.fallback=0;s.expected=s.evidence.expected;
  std::vector<size_t> valid;
  for(size_t i=0;i<s.pending.valid.size();++i) if(s.pending.valid[i]&&s.evidence.mass[i]>0) {
    bool finite=true;for(int j=0;j<s.d;++j) finite &= std::isfinite(s.pending.positions[i*s.d+j]);
    if(!finite) continue;
    valid.push_back(i);const float* x=s.pending.positions.data()+i*s.d;
    if(s.models.empty()||(s.models.size()<16 && s.offset(x,s.models[s.nearest(x)].anchor.data()).norm()/std::sqrt(double(s.d))>.1)) s.models.push_back(s.fresh(x));
  }
  std::vector<std::vector<size_t>> rows(s.models.size());
  for(size_t i:valid) rows[s.nearest(s.pending.positions.data()+i*s.d)].push_back(i);
  for(size_t i=0;i<s.models.size();++i) s.fit(s.models[i],rows[i]);
  s.pending={};s.evidence={};s.dirty=false;++s.version;
}
void CloningGuided::reset() {impl->models.clear();impl->pending={};impl->evidence={};impl->dirty=false;++impl->version;}
void CloningGuided::sample(const float* x,float* delta,int d,Rng& rng) const {
  if(d!=impl->d) throw std::invalid_argument("Proposal dimensions");
  impl->draw(x,delta,impl->scale(NAN),rng);
}
fractal::ProposalTrial CloningGuided::propose_with_objective(const float* x,float* delta,int d,Rng& rng,fractal::TrialIdentity id,double objective) const {
  if(d!=impl->d) throw std::invalid_argument("Proposal dimensions");
  fractal::ProposalTrial trial;id.model=impl->version;trial.identity=id;trial.origin.assign(x,x+d);trial.scale=impl->scale(objective);
  impl->draw(x,delta,trial.scale,rng);trial.direction.resize(d);
  for(int j=0;j<d;++j) trial.direction[j]=trial.scale>0?delta[j]/trial.scale:0;
  return trial;
}
void CloningGuided::continue_trial(const fractal::ProposalTrial& trial,float* delta,int d,Rng& rng) const {
  if(d!=impl->d) throw std::invalid_argument("Proposal dimensions");
  impl->draw(trial.origin.data(),delta,trial.scale,rng);
}
Json CloningGuided::diagnostics() const {
  auto& s=*impl;Json j;j.kind=Json::Object;double parents=0,condition=1,ratio=0;
  for(auto& m:s.models) {parents+=m.families;condition=std::max(condition,m.condition);ratio=std::max(ratio,m.drift.norm()/std::sqrt(double(s.d)));}
  j.object["model_count"]=number(s.models.size());j.object["model_version"]=number(s.version);
  j.object["effective_parents"]=number(s.models.empty()?0:parents/s.models.size());
  j.object["condition_number"]=number(condition);j.object["drift_noise_ratio"]=number(ratio);j.object["fallback_count"]=number(s.fallback);
  j.object["scale_min"]=number(s.low);j.object["scale_max"]=number(s.upper);
  str(j,"weighting",s.expected?"expected":"realized");str(j,"strategy","cloning_guided");
  str(j,"fallback_reason",s.fallback?"Insufficient independent support, degenerate geometry, or failed fit":"none");return j;
}
Json CloningGuided::geometry() const {
  Json list;list.kind=Json::Array;auto& s=*impl;
  for(const auto& m:s.models) {
    Json j;j.kind=Json::Object;str(j,"strategy","cloning_guided");str(j,"mode",s.mode);
    j.object["version"]=number(1);j.object["dimensions"]=number(s.d);j.object["columns"]=number(m.shape.cols());j.object["scale"]=number(1);
    j.object["anchor"]=array(std::vector<double>(m.anchor.begin(),m.anchor.end()));
    std::vector<double> values;for(int i=0;i<s.d;++i) for(int k=0;k<m.shape.cols();++k) values.push_back(m.shape(i,k));j.object["shape"]=array(values);list.array.push_back(j);
  }return list;
}
void CloningGuided::restore_geometry(const Json& list) {
  if(list.items().size()>64) throw std::invalid_argument("Too many movement models");
  std::vector<Impl::Model> models;auto& s=*impl;
  for(const auto& j:list.items()) {
    if(j["strategy"].str()!="cloning_guided") continue;
    validate_adaptive_geometry(j,s.d);if(j["mode"].str()!=s.mode) continue;
    std::vector<float> anchor;for(const auto& v:j["anchor"].items()) anchor.push_back(float(v.num()));auto m=s.fresh(anchor.data());
    int cols=int(j["columns"].num());m.shape.resize(s.d,cols);
    for(int i=0;i<s.d;++i) for(int k=0;k<cols;++k) m.shape(i,k)=j["shape"].array[size_t(i)*cols+k].num();
    if(s.d<=64) {Eigen::LLT<Mat> chol(m.shape);m.factor=chol.matrixL();}
    models.push_back(m);if(models.size()==16) break;
  }s.models=std::move(models);s.pending={};s.evidence={};s.dirty=false;++s.version;
}
}
