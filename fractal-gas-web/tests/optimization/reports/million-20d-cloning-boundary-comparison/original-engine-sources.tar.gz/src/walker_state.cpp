#include "walker_state.hpp"

#include "tensor_ops.hpp"

namespace fg {

WalkerState WalkerState::clone(const std::vector<int32_t>& companions,
                               const std::vector<uint8_t>& will_clone) const {
  WalkerState out;
  out.N = N;
  out.obs_dim = obs_dim;
  out.action_dim = action_dim;

  out.states = states;
  for (size_t i = 0; i < will_clone.size(); ++i) {
    if (will_clone[i]) out.states[i] = states[static_cast<size_t>(companions[i])];
  }

  out.observations = gather_clone_rows(observations, companions, will_clone, obs_dim);
  out.rewards = gather_clone(rewards, companions, will_clone);
  out.step_rewards = gather_clone(step_rewards, companions, will_clone);
  out.dones = gather_clone(dones, companions, will_clone);
  out.truncated = gather_clone(truncated, companions, will_clone);
  out.actions = gather_clone(actions, companions, will_clone);
  out.dt = gather_clone(dt, companions, will_clone);
  if (!root_actions.empty()) out.root_actions = gather_clone(root_actions, companions, will_clone);
  if (!actual_dt.empty()) out.actual_dt = gather_clone(actual_dt, companions, will_clone);
  if (!recoverable.empty()) out.recoverable = gather_clone(recoverable, companions, will_clone);

  out.has_virtual_rewards = has_virtual_rewards;
  if (has_virtual_rewards) {
    out.virtual_rewards = gather_clone(virtual_rewards, companions, will_clone);
  }
  out.has_infos = has_infos;
  if (has_infos) out.infos = gather_clone(infos, companions, will_clone);
  if (!lineage.empty()) out.lineage = gather_clone(lineage, companions, will_clone);
  return out;
}

void WalkerState::inject(const WalkerState& source, int32_t count) {
  const auto d = static_cast<size_t>(obs_dim);
  for (int32_t i = 0; i < count; ++i) {
    const auto ui = static_cast<size_t>(i);
    states[ui] = source.states[ui];
    for (size_t k = 0; k < d; ++k) {
      observations[ui * d + k] = source.observations[ui * d + k];
    }
    rewards[ui] = source.rewards[ui];
    step_rewards[ui] = source.step_rewards[ui];
    dones[ui] = source.dones[ui];
    truncated[ui] = source.truncated[ui];
    actions[ui] = source.actions[ui];
    dt[ui] = source.dt[ui];
    if (!root_actions.empty() && !source.root_actions.empty())
      root_actions[ui] = source.root_actions[ui];
    if (!actual_dt.empty() && !source.actual_dt.empty()) actual_dt[ui] = source.actual_dt[ui];
    if (!recoverable.empty() && !source.recoverable.empty())
      recoverable[ui] = source.recoverable[ui];
    if (has_virtual_rewards && source.has_virtual_rewards) {
      virtual_rewards[ui] = source.virtual_rewards[ui];
    }
    if (has_infos && source.has_infos) infos[ui] = source.infos[ui];
    if (!lineage.empty() && !source.lineage.empty()) lineage[ui] = source.lineage[ui];
  }
}

WalkerState WalkerState::extract(const WalkerState& s, const std::vector<int32_t>& indices) {
  WalkerState out;
  out.N = static_cast<int32_t>(indices.size());
  out.obs_dim = s.obs_dim;
  out.action_dim = s.action_dim;
  const auto d = static_cast<size_t>(s.obs_dim);

  out.states.reserve(indices.size());
  out.observations.resize(indices.size() * d);
  out.rewards.resize(indices.size());
  out.step_rewards.resize(indices.size());
  out.dones.resize(indices.size());
  out.truncated.resize(indices.size());
  out.actions.resize(indices.size());
  out.dt.resize(indices.size());
  if (!s.root_actions.empty()) out.root_actions.resize(indices.size());
  if (!s.actual_dt.empty()) out.actual_dt.resize(indices.size());
  if (!s.recoverable.empty()) out.recoverable.resize(indices.size());
  out.has_virtual_rewards = s.has_virtual_rewards;
  if (s.has_virtual_rewards) out.virtual_rewards.resize(indices.size());
  out.has_infos = s.has_infos;
  if (s.has_infos) out.infos.resize(indices.size());
  if (!s.lineage.empty()) out.lineage.resize(indices.size());

  for (size_t i = 0; i < indices.size(); ++i) {
    const auto j = static_cast<size_t>(indices[i]);
    out.states.push_back(s.states[j]);
    for (size_t k = 0; k < d; ++k) out.observations[i * d + k] = s.observations[j * d + k];
    out.rewards[i] = s.rewards[j];
    out.step_rewards[i] = s.step_rewards[j];
    out.dones[i] = s.dones[j];
    out.truncated[i] = s.truncated[j];
    out.actions[i] = s.actions[j];
    out.dt[i] = s.dt[j];
    if (!s.root_actions.empty()) out.root_actions[i] = s.root_actions[j];
    if (!s.actual_dt.empty()) out.actual_dt[i] = s.actual_dt[j];
    if (!s.recoverable.empty()) out.recoverable[i] = s.recoverable[j];
    if (s.has_virtual_rewards) out.virtual_rewards[i] = s.virtual_rewards[j];
    if (s.has_infos) out.infos[i] = s.infos[j];
    if (!s.lineage.empty()) out.lineage[i] = s.lineage[j];
  }
  return out;
}

WalkerState WalkerState::concat(const WalkerState& a, const WalkerState& b) {
  WalkerState out;
  out.N = a.N + b.N;
  out.obs_dim = a.obs_dim;
  out.action_dim = a.action_dim;

  auto cat = [](auto& dst, const auto& x, const auto& y) {
    dst = x;
    dst.insert(dst.end(), y.begin(), y.end());
  };
  cat(out.states, a.states, b.states);
  cat(out.observations, a.observations, b.observations);
  cat(out.rewards, a.rewards, b.rewards);
  cat(out.step_rewards, a.step_rewards, b.step_rewards);
  cat(out.dones, a.dones, b.dones);
  cat(out.truncated, a.truncated, b.truncated);
  cat(out.actions, a.actions, b.actions);
  cat(out.dt, a.dt, b.dt);
  if (!a.root_actions.empty() && !b.root_actions.empty())
    cat(out.root_actions, a.root_actions, b.root_actions);
  if (!a.actual_dt.empty() && !b.actual_dt.empty()) cat(out.actual_dt, a.actual_dt, b.actual_dt);
  if (!a.recoverable.empty() && !b.recoverable.empty())
    cat(out.recoverable, a.recoverable, b.recoverable);
  // Python guard: concat vr only when both sides have it.
  out.has_virtual_rewards = a.has_virtual_rewards && b.has_virtual_rewards;
  if (out.has_virtual_rewards) {
    cat(out.virtual_rewards, a.virtual_rewards, b.virtual_rewards);
  }
  out.has_infos = a.has_infos && b.has_infos;
  if (out.has_infos) cat(out.infos, a.infos, b.infos);
  if (!a.lineage.empty() && !b.lineage.empty()) cat(out.lineage, a.lineage, b.lineage);
  return out;
}

}  // namespace fg
