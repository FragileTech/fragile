// Emscripten embind surface. The whole module is meant to run inside a Web
// Worker (worker.js) — fg_step() blocks while the thread pool works, so it
// must never be called on the browser main thread.
//
// Three consoles are supported end-to-end:
//   0 = NES / Super Mario Bros  (nes-py core, pthread-parallel)
//   1 = Atari 2600              (ALE core, pthread-parallel; game 1 =
//       Montezuma's Revenge with dedicated logic)
//   2 = Sega Genesis (Genesis Plus GX statically linked into a shim module
//       instantiated once per plain Web Worker — RetroFarmEnv dispatches
//       walker steps to N such workers in parallel via shared memory)
// Four solver modes: 0 = Wave, 1 = Graph, 2 = FMC, 3 = Jump Wave.
// FMC and Jump Wave use FractalGas search through ArcadePlanner.
#ifdef __EMSCRIPTEN__

#include <emscripten/bind.h>
#include <emscripten/val.h>

#include <algorithm>
#include <cstdio>
#include <fstream>
#include <memory>
#include <string>

#include "atari_env.hpp"
#include "arcade_memory.hpp"
#include "arcade_planner.hpp"
#include "arcade_trajectory.hpp"
#include "fractal_gas.hpp"
#include "fractal_tree.hpp"
#include "nes_env.hpp"
#include "retro_farm_env.hpp"
#include "swarm_algorithm.hpp"

namespace {

std::unique_ptr<fg::BatchEnv> g_env;
fg::NesMarioEnv* g_nes = nullptr;  // non-owning; set when console == 0
fg::AtariEnv* g_atari = nullptr;   // non-owning; set when console == 1
std::unique_ptr<fg::SwarmAlgorithm> g_algo;
std::unique_ptr<fg::ArcadePlanner> g_planner;
int g_algorithm = 0;
int g_max_walkers = 0;  // effective Graph cap after the memory clamp
std::string g_last_error;
std::vector<uint8_t> g_frame;
fg::ArcadeTrajectory g_trajectory;

// Scratch buffers for the per-walker arrays (copied to plain JS typed
// arrays before they are returned, so JS never aliases wasm memory).
std::vector<int32_t> g_wx, g_wy, g_ww, g_ws, g_parent;
std::vector<uint8_t> g_alive, g_leaf;
std::vector<int32_t> g_tcx, g_tcy, g_tz, g_ta;
std::vector<int32_t> g_vkeys;
std::vector<float> g_vsums;

struct FgParams {
  int n = 32;         // Wave: N walkers; Graph: start walkers = min leaves
  float distCoef = 1.0f;
  float rewardCoef = 1.0f;
  bool useCumulativeReward = true;
  int dtMin = 1;
  int dtMax = 4;
  int nElite = 2;
  double seed = 0;
  int nThreads = 4;
  double memoryLimitBytes = 512.0 * 1024 * 1024;
  int obsMode = 0;   // 0=RAM, 1=RGB, 2=Gray, 3=Coords
  int world = 1;     // NES start level: world 1-8
  int stage = 1;     // NES start level: stage 1-4
  int console = 0;   // 0=NES, 1=Atari, 2=Genesis
  int game = 0;      // Genesis: 0=Airstriker, 1=Sonic; Atari: 0=generic,
                     // 1=Montezuma's Revenge (dedicated RAM logic + map)
  int algorithm = 0;   // 0=Wave (FractalGas), 1=Graph (FractalTree)
  int horizon = 32;
  bool consensusPrefix = true;
  int maxHorizon = 0;
  int maxWalkers = 0;  // Graph: population cap, 0 = console default
  int freezePrefixAfter = 0;  // Graph: 0 disables shared-prefix archiving
  float eraseCoef = 0.05f;  // Graph: visit-count decay
  int aggBlock = 5;         // Graph: visit-count pooling window (px), live
  bool visitReward = true;  // visit-count term in the reward (ablation), live
  float visitCoef = 1.0f;   // exponent on the visit-count term, live
  // Genesis core-worker farm, pre-spawned by worker.js (nested workers need
  // the JS event loop, which fg_init blocks): region base pointer, worker
  // count, and the blob size the workers reported.
  double farmPtr = 0;
  int farmWorkers = 0;
  int farmBlobLen = 0;
};

fg::FractalGasParams to_gas_params(const FgParams& p) {
  fg::FractalGasParams params;
  params.N = p.n;
  params.max_walkers = p.maxWalkers > 0 ? p.maxWalkers : p.n;
  params.dist_coef = p.distCoef;
  params.reward_coef = p.rewardCoef;
  params.use_cumulative_reward = p.useCumulativeReward;
  params.dt_min = p.dtMin;
  params.dt_max = p.dtMax;
  params.n_elite = p.nElite;
  params.record_frames = true;
  params.recording = fg::RecordingMode::Pruned;
  params.record_observations = false;
  if (p.algorithm >= 2) {
    params.record_frames = false;
    params.recording = fg::RecordingMode::Pruned;
    params.record_observations = false;
  }
  params.seed = static_cast<uint64_t>(p.seed);
  params.count_visits = true;  // effective only with a visit key (Coords)
  params.visit_reward = p.visitReward;
  params.visit_coef = p.visitCoef;
  params.erase_coef = p.eraseCoef;
  params.agg_block_size = p.aggBlock < 1 ? 1 : p.aggBlock;
  return params;
}

// Two populations (current and output), plus bounded history, runtime,
// emulator communication regions and allocator/transient headroom.
int population_capacity(const FgParams& p) {
  std::vector<char> state;
  std::vector<float> obs;
  g_env->reset(state, obs);
  const uint64_t per = (p.algorithm == 1 ? 2ULL : 4ULL) * (state.size() + uint64_t(obs.size()) * 4) + 1024;
  const uint64_t reserve = (160ULL + 128ULL) * 1024 * 1024 +
      uint64_t(p.farmWorkers) * (128 + 0x200000 + 0x100000 + 0x80000 + 0x1000) +
      uint64_t(std::max(p.nElite, 0)) * 2 * (state.size() + uint64_t(obs.size()) * 4);
  const uint64_t heap = uint64_t(p.memoryLimitBytes);
  const int cap = heap > reserve ? int(std::min<uint64_t>((heap - reserve) / per, 100000)) : 0;
  if (p.n > cap)
    throw std::runtime_error("Requested population exceeds the main engine memory limit (estimated safe maximum " +
        std::to_string(cap) + "). Reduce walkers or select a larger engine memory limit.");
  return cap;
}

int clamp_max_walkers(const FgParams& p) {
  const int defaults[3] = {4000, 20000, 150};
  const int console = p.console < 0 || p.console > 2 ? 0 : p.console;
  const int requested = std::max(p.n, p.maxWalkers > 0 ? p.maxWalkers : defaults[console]);
  return std::min(requested, population_capacity(p));
}

fg::FractalTreeParams to_tree_params(const FgParams& p) {
  fg::FractalTreeParams params;
  if (p.freezePrefixAfter < 0 || p.freezePrefixAfter > 100000)
    throw std::invalid_argument("Invalid Graph prefix threshold");
  params.freeze_prefix_after = p.freezePrefixAfter;
  params.max_frozen_bytes = 128ULL * 1024 * 1024;
  params.start_walkers = std::max(p.n, 1);
  params.min_leafs = std::max(p.n, 1);
  params.max_walkers = clamp_max_walkers(p);
  params.dist_coef = p.distCoef;
  params.reward_coef = p.rewardCoef;
  params.dt_min = p.dtMin;
  params.dt_max = p.dtMax;
  params.count_visits = true;  // effective only with a visit key (Coords)
  params.erase_coef = p.eraseCoef;
  params.agg_block_size = p.aggBlock < 1 ? 1 : p.aggBlock;
  params.visit_reward = p.visitReward;
  params.visit_coef = p.visitCoef;
  params.record_frames = true;
  params.seed = static_cast<uint64_t>(p.seed);
  return params;
}

void write_bytes(const char* path, emscripten::val data) {
  const std::vector<uint8_t> bytes =
      emscripten::convertJSArrayToNumberVector<uint8_t>(data);
  std::ofstream f(path, std::ios::binary);
  f.write(reinterpret_cast<const char*>(bytes.data()),
          static_cast<std::streamsize>(bytes.size()));
}

/// rom: Uint8Array of the ROM for the selected console.
/// aux: Uint8Array of the gpgx.so side module (Genesis only; else empty).
bool fg_init(emscripten::val rom, emscripten::val aux, const FgParams& p) {
  try {
    g_trajectory.clear();
    g_planner.reset();
    g_algo.reset();
    g_env.reset();
    g_nes = nullptr;
    g_atari = nullptr;

    if (!std::isfinite(p.memoryLimitBytes) || p.memoryLimitBytes < 512.0 * 1024 * 1024 ||
        p.memoryLimitBytes > 4294967296.0)
      throw std::invalid_argument("Invalid main engine memory limit");
    fg::arcade_memory::limit = uint64_t(p.memoryLimitBytes);
    const int threads = std::clamp(p.nThreads, 1, 20);
    const int mode_int = p.obsMode < 0 || p.obsMode > 3 ? 0 : p.obsMode;

    switch (p.console) {
      case 1: {  // Atari 2600 via ALE
        write_bytes("/rom.bin", rom);
        auto atari = std::make_unique<fg::AtariEnv>(
            "/rom.bin", threads, static_cast<fg::AtariObsMode>(mode_int),
            p.game == 1 ? fg::AtariGame::kMontezuma : fg::AtariGame::kGeneric);
        g_atari = atari.get();
        g_env = std::move(atari);
        break;
      }
      case 2: {  // Sega Genesis via per-worker shim modules (parallel)
        (void)aux;
        (void)rom;  // the ROM went to the core workers, not this module
        g_env = std::make_unique<fg::RetroFarmEnv>(
            static_cast<uintptr_t>(p.farmPtr), p.farmWorkers,
            static_cast<size_t>(p.farmBlobLen), mode_int,
            p.game == 1 ? fg::RetroGame::kSonic
                        : fg::RetroGame::kAirstriker);
        break;
      }
      default: {  // NES / Super Mario Bros
        write_bytes("/rom.nes", rom);
        auto nes = std::make_unique<fg::NesMarioEnv>(
            "/rom.nes", threads, static_cast<fg::ObsMode>(mode_int), p.world,
            p.stage);
        g_nes = nes.get();
        g_env = std::move(nes);
        break;
      }
    }

    if (p.algorithm < 0 || p.algorithm > 3)
      throw std::invalid_argument("Unknown arcade algorithm");
    if (p.n < 1 || p.dtMin < 1 || p.dtMax < p.dtMin)
      throw std::invalid_argument("Walkers and action durations must be positive; dt max must be at least dt min");
    const int capacity = population_capacity(p);
    if (p.algorithm != 1) {
      const int maximum = p.maxWalkers > 0 ? p.maxWalkers : p.n;
      if (maximum < p.n || maximum > 1024 || maximum > capacity || p.nElite > p.n)
        throw std::invalid_argument("Maximum walkers must cover active walkers and fit the engine memory limit (up to 1024)");
    }
    g_algorithm = p.algorithm;
    if (g_algorithm == 1) {
      const fg::FractalTreeParams tp = to_tree_params(p);
      g_max_walkers = tp.max_walkers;
      g_algo = std::make_unique<fg::FractalTree>(*g_env, tp);
    } else {
      g_max_walkers = p.maxWalkers > 0 ? p.maxWalkers : p.n;
      g_algo = std::make_unique<fg::FractalGas>(*g_env, to_gas_params(p));
    }
    if (g_algorithm >= 2) {
      g_planner = std::make_unique<fg::ArcadePlanner>(*g_env,
          *static_cast<fg::FractalGas*>(g_algo.get()),
          fg::ArcadePlannerSettings{p.algorithm, p.horizon, p.consensusPrefix, p.maxHorizon});
      g_planner->reset();
    } else {
      g_algo->reset();
    }
    g_last_error.clear();
    return true;
  } catch (const std::exception& e) {
    g_last_error = e.what();
    g_planner.reset();
    g_algo.reset();
    g_env.reset();
    g_nes = nullptr;
    g_atari = nullptr;
    return false;
  }
}

std::string fg_last_error() { return g_last_error; }
int fg_algorithm() { return g_algorithm; }
int fg_max_walkers() { return g_max_walkers; }

emscripten::val fg_population_status() {
  auto* gas = dynamic_cast<fg::FractalGas*>(g_algo.get());
  if (!gas) return emscripten::val::null();
  const auto s = gas->population_status();
  auto out = emscripten::val::object();
  out.set("maximum", s.maximum);
  out.set("active", s.active);
  out.set("requested", s.requested);
  out.set("removal_policy", std::string(fg::fractal::removal_policy_name(s.policy)));
  out.set("pending", s.pending());
  return out;
}
bool fg_set_population(int count, const std::string& policy) {
  try {
    auto* gas = dynamic_cast<fg::FractalGas*>(g_algo.get());
    if (!gas) throw std::invalid_argument("Live population changes require Wave, FMC, or Wave Jump");
    fg::fractal::validate_population(count, g_max_walkers, gas->params().n_elite, 2);
    const auto removal = fg::fractal::removal_policy(policy);
    if (g_planner) g_planner->set_population(count, removal);
    else gas->set_population(count, removal);
    g_trajectory.clear();
    return true;
  } catch (const std::exception& e) {
    g_last_error = e.what();
    return false;
  }
}

template <typename T>
emscripten::val copy_array(const std::vector<T>& v) {
  // A fresh, non-shared typed array (slice of a view into wasm memory).
  return emscripten::val(emscripten::typed_memory_view(v.size(), v.data()))
      .template call<emscripten::val>("slice");
}

emscripten::val fg_step_impl() {
  g_trajectory.clear();
  if (!g_algo) return emscripten::val::null();
  const fg::StepInfo info = g_planner ? g_planner->advance() : g_algo->step();
  emscripten::val out = emscripten::val::object();
  out.set("population", fg_population_status());
  out.set("iteration", info.iteration);
  out.set("numCloned", info.num_cloned);
  out.set("numRevived", info.num_revived);
  out.set("aliveCount", info.alive_count);
  out.set("meanReward", info.mean_reward);
  out.set("maxReward", info.max_reward);
  out.set("minReward", info.min_reward);
  out.set("meanVirtualReward", info.mean_virtual_reward);
  out.set("maxVirtualReward", info.max_virtual_reward);
  out.set("minVirtualReward", info.min_virtual_reward);
  out.set("meanDt", info.mean_dt);
  out.set("bestWalkerIdx", info.best_walker_idx);
  out.set("totalSteps", static_cast<double>(g_algo->total_steps()));
  out.set("totalClones", static_cast<double>(g_algo->total_clones()));
  out.set("totalFrames", static_cast<double>(g_algo->total_frames()));
  out.set("walkerCount", info.n_walkers);
  out.set("nLeaves", info.n_leaves);
  out.set("numStepped", info.num_stepped);
  out.set("algorithm", g_algorithm);
  if (g_planner) {
    out.set("phase", g_planner->phase());
    out.set("searchDepth", g_planner->depth());
    out.set("searchAdvanced", g_planner->search_advanced());
    out.set("committedScore", g_planner->score());
    out.set("committedReward", g_planner->reward());
    out.set("playedFrames", static_cast<double>(g_planner->played_frames()));
    out.set("gameDone", g_planner->done());
    out.set("executionMode", g_planner->execution_mode());
    if (g_planner->has_info()) {
      const auto& committed = g_planner->info();
      out.set("committedWorld", committed.world);
      out.set("committedLevel", committed.stage);
      out.set("committedLives", committed.lives);
    }
  }

  const int32_t n = g_algo->n_walkers();
  if (g_algo->has_walker_info() && n > 0) {
    // Per-walker swarm data for the map overlays, valid by WALKER index for
    // all modes: position, level ids, alive flag, and the tree
    // structure (parent index, leaf flag; the wave reports parent = self).
    const auto un = static_cast<size_t>(n);
    g_wx.resize(un); g_wy.resize(un); g_ww.resize(un); g_ws.resize(un);
    g_parent.resize(un); g_alive.resize(un); g_leaf.resize(un);
    for (int32_t i = 0; i < n; ++i) {
      const fg::WalkerInfo& wi = g_algo->walker_info(i);
      const auto ui = static_cast<size_t>(i);
      g_wx[ui] = wi.x;
      g_wy[ui] = wi.y;
      g_ww[ui] = wi.world;
      g_ws[ui] = wi.stage;
      g_parent[ui] = g_algo->walker_parent(i);
      g_alive[ui] = g_algo->walker_alive(i) ? 1 : 0;
      g_leaf[ui] = g_algo->walker_is_leaf(i) ? 1 : 0;
    }
    out.set("walkerX", copy_array(g_wx));
    out.set("walkerY", copy_array(g_wy));
    out.set("walkerWorld", copy_array(g_ww));
    out.set("walkerStage", copy_array(g_ws));
    out.set("walkerParent", copy_array(g_parent));
    out.set("walkerAlive", copy_array(g_alive));
    out.set("walkerLeaf", copy_array(g_leaf));
    if (auto* graph = dynamic_cast<fg::FractalTree*>(g_algo.get())) {
      std::vector<float> fx, fy;
      std::vector<int32_t> fw, fs;
      std::vector<double> fid, fparent;
      for (const auto& node : graph->frozen_nodes()) {
        if (!node.prefix) continue;
        fx.push_back(node.info.x); fy.push_back(node.info.y);
        fw.push_back(node.info.world); fs.push_back(node.info.stage);
        fid.push_back(static_cast<double>(node.id));
        fparent.push_back(static_cast<double>(node.parent_id));
      }
      out.set("frozenX", copy_array(fx)); out.set("frozenY", copy_array(fy));
      out.set("frozenWorld", copy_array(fw)); out.set("frozenStage", copy_array(fs));
      out.set("frozenId", copy_array(fid)); out.set("frozenParentId", copy_array(fparent));
      out.set("activeRootId", static_cast<double>(graph->active_root_id()));
      out.set("activeRootParentId", static_cast<double>(graph->state().parent_ids[0]));
    }
    if (dynamic_cast<fg::RetroFarmEnv*>(g_env.get()) != nullptr) {
      // Per-walker camera (Sonic), kept for callers that pair it by walker.
      g_tcx.resize(un); g_tcy.resize(un);
      for (int32_t i = 0; i < n; ++i) {
        const fg::WalkerInfo& wi = g_algo->walker_info(i);
        g_tcx[static_cast<size_t>(i)] = wi.cam_x;
        g_tcy[static_cast<size_t>(i)] = wi.cam_y;
      }
      out.set("walkerCamX", copy_array(g_tcx));
      out.set("walkerCamY", copy_array(g_tcy));
    }
    const fg::WalkerInfo& best = g_algo->walker_info(info.best_walker_idx);
    out.set("world", best.world);
    out.set("level", best.stage);
    if (g_atari) {
      out.set("lives", best.lives);
      out.set("inventory", best.inventory);
    }
  }
  if (auto* farm = dynamic_cast<fg::RetroFarmEnv*>(g_env.get())) {
    // Sonic fog-of-war tiles are indexed by BATCH position of the last
    // step (a subset of the walkers in Graph mode): ship the camera and
    // level of each tile alongside so the UI can pair them.
    const int32_t t = farm->walker_count();
    const auto ut = static_cast<size_t>(t);
    g_tcx.resize(ut); g_tcy.resize(ut); g_tz.resize(ut); g_ta.resize(ut);
    for (int32_t j = 0; j < t; ++j) {
      const auto uj = static_cast<size_t>(j);
      g_tcx[uj] = farm->walker_cam_x(j);
      g_tcy[uj] = farm->walker_cam_y(j);
      g_tz[uj] = farm->walker_zone(j);
      g_ta[uj] = farm->walker_act(j);
    }
    out.set("tileCount", t);
    out.set("tileCamX", copy_array(g_tcx));
    out.set("tileCamY", copy_array(g_tcy));
    out.set("tileZone", copy_array(g_tz));
    out.set("tileAct", copy_array(g_ta));
  }
  return out;
}

emscripten::val fg_step() {
  try {
    return fg_step_impl();
  } catch (const std::exception& e) {
    g_last_error = e.what();
    auto out = emscripten::val::object();
    out.set("error", g_last_error);
    return out;
  }
}

/// Fog-of-war tiles: tileCount x 40x28 RGB bytes from the last Genesis step
/// (view into wasm memory — copy on the JS side before using across steps).
emscripten::val fg_get_walker_tiles() {
  auto* farm = dynamic_cast<fg::RetroFarmEnv*>(g_env.get());
  if (!farm || farm->walker_tiles_size() == 0) return emscripten::val::null();
  return emscripten::val(emscripten::typed_memory_view(
      farm->walker_tiles_size(), farm->walker_tiles()));
}

/// RGBA bytes of the showcased walker's frame (view into wasm memory — copy
/// on the JS side before transferring).
emscripten::val fg_get_best_frame() {
  if (!g_algo) return emscripten::val::null();
  g_frame = g_planner ? g_planner->frame() : g_algo->best_frame();
  if (g_frame.empty()) return emscripten::val::null();
  return emscripten::val(
      emscripten::typed_memory_view(g_frame.size(), g_frame.data()));
}

/// RGBA frame of walker i's CURRENT state (view into wasm memory — copy on
/// the JS side before transferring). Used by the Montezuma pyramid map to
/// capture a room image the first time a walker enters it. Null for a tree
/// slot that has no state yet.
emscripten::val fg_render_walker_frame(int i) {
  if (!g_algo || !g_env) return emscripten::val::null();
  if (i < 0 || i >= g_algo->n_walkers()) return emscripten::val::null();
  const std::vector<char>& state = g_algo->walker_state(i);
  if (state.empty()) return emscripten::val::null();
  g_env->render_frame(state, g_frame);
  if (g_frame.empty()) return emscripten::val::null();
  return emscripten::val(
      emscripten::typed_memory_view(g_frame.size(), g_frame.data()));
}

// Capture at a search-update boundary; return owned arrays and release C++ storage.
emscripten::val fg_select_trajectory(int walker) {
  auto out = emscripten::val::object();
  try {
    if (!g_algo) throw std::runtime_error("Start a run first");
    g_trajectory.select(*g_algo, g_planner.get(), walker);
    out.set("length", static_cast<double>(g_trajectory.size()));
    out.set("walker", g_trajectory.walker);
    out.set("walkerCount", g_algo->n_walkers());
    out.set("iteration", g_algo->iteration_count());
    auto root = emscripten::val::global("Uint8Array").new_(emscripten::val(
        emscripten::typed_memory_view(g_trajectory.root.size(),
          reinterpret_cast<const uint8_t*>(g_trajectory.root.data()))));
    auto actions = emscripten::val::global("Int32Array").new_(emscripten::val(
        emscripten::typed_memory_view(g_trajectory.actions.size() * 2,
          reinterpret_cast<const int32_t*>(g_trajectory.actions.data()))));
    out.set("root", root); out.set("actions", actions);
    g_trajectory.clear();
  } catch (const std::exception& e) {
    g_trajectory.clear();
    out.set("error", std::string(e.what()));
  }
  return out;
}
emscripten::val fg_trajectory_frame(int index) {
  auto out = emscripten::val::object();
  try {
    if (!g_env || index < 0) throw std::runtime_error("Invalid trajectory request");
    const bool ready = g_trajectory.seek(*g_env, size_t(index), g_frame);
    out.set("ready", ready);
    if (ready) {
      if (g_frame.size() != size_t(g_env->frame_width()) * g_env->frame_height() * 4)
        throw std::runtime_error("This state has no display frame");
      out.set("frame", copy_array(g_frame));
    }
  } catch (const std::exception& e) { out.set("error", std::string(e.what())); }
  return out;
}

/// Visit counting active (Coords on a game with a map), either algorithm.
bool fg_counting_visits() {
  return g_algo != nullptr && g_algo->counting_visits();
}

/// The Graph's visit-count grid for the map heatmap: every nonzero 5x5
/// block as {count, keys: Int32Array [plane, bx, by] * count, sums:
/// Float32Array, blockSize}. Null when visits are not counted.
emscripten::val fg_get_visit_blocks() {
  if (!fg_counting_visits() || g_algo->visit_grid() == nullptr) {
    return emscripten::val::null();
  }
  const fg::VisitGrid& grid = *g_algo->visit_grid();
  grid.export_blocks(g_vkeys, g_vsums);
  emscripten::val out = emscripten::val::object();
  out.set("count", static_cast<int>(g_vsums.size()));
  out.set("blockSize", grid.block_size());
  out.set("keys", copy_array(g_vkeys));
  out.set("sums", copy_array(g_vsums));
  return out;
}

int fg_frame_width() { return g_env ? g_env->frame_width() : 0; }
int fg_frame_height() { return g_env ? g_env->frame_height() : 0; }
int fg_n_actions() { return g_env ? g_env->n_actions() : 0; }

/// Live-tunable parameters. Population updates use setPopulation. Changing seed/console/obsMode/level/algorithm
/// requires fg_init again.
void fg_set_params_impl(const FgParams& p) {
  if (!g_algo) return;
  if (p.dtMin < 1 || p.dtMax < p.dtMin)
    throw std::invalid_argument("dt max must be at least dt min, and both must be positive");
  if (g_planner) g_planner->configure(
      {g_algorithm, p.horizon, p.consensusPrefix, p.maxHorizon});
  g_algo->set_dist_coef(p.distCoef);
  g_algo->set_reward_coef(p.rewardCoef);
  g_algo->set_use_cumulative_reward(p.useCumulativeReward);
  g_algo->set_dt_range(p.dtMin, p.dtMax);
  g_algo->set_n_elite(p.nElite);
  g_algo->set_erase_coef(p.eraseCoef);
  g_algo->set_agg_block_size(p.aggBlock < 1 ? 1 : p.aggBlock);
  g_algo->set_visit_reward(p.visitReward);
  g_algo->set_visit_coef(p.visitCoef);
}

bool fg_set_params(const FgParams& p) {
  try {
    fg_set_params_impl(p);
    return true;
  } catch (const std::exception& e) {
    g_last_error = e.what();
    return false;
  }
}

void fg_reset() {
  g_trajectory.clear();
  if (g_planner) g_planner->reset();
  else if (g_algo) g_algo->reset();
}

/// Live-tunable reward term weights, as a JS array of numbers in the
/// console's field order: Mario [x, time, death, clip, flag, area]; Sonic
/// [dx, rings, score, cell, life, boss, act]; Montezuma [score, room].
/// Ignored for generic Atari games (raw score).
void fg_set_reward_weights(emscripten::val weights) {
  if (!g_env) return;
  if (g_planner) g_planner->invalidate();
  const int len = weights["length"].as<int>();
  auto at = [&](int i, float fallback) {
    return i < len ? weights[i].as<float>() : fallback;
  };
  if (g_nes) {
    fg::MarioRewardWeights w;
    w.x = at(0, w.x);
    w.time = at(1, w.time);
    w.death = at(2, w.death);
    w.clip = at(3, w.clip);
    w.flag = at(4, w.flag);
    w.area = at(5, w.area);
    g_nes->set_reward_weights(w);
  } else if (auto* farm = dynamic_cast<fg::RetroFarmEnv*>(g_env.get())) {
    fg::SonicRewardWeights w;
    w.dx = at(0, w.dx);
    w.rings = at(1, w.rings);
    w.score = at(2, w.score);
    w.cell = at(3, w.cell);
    w.life = at(4, w.life);
    w.boss = at(5, w.boss);
    w.act = at(6, w.act);
    farm->set_reward_weights(w);
  } else if (g_atari && g_atari->game() == fg::AtariGame::kMontezuma) {
    fg::MontezumaRewardWeights w;
    w.score = at(0, w.score);
    w.room = at(1, w.room);
    g_atari->set_reward_weights(w);
  }
}

}  // namespace

EMSCRIPTEN_BINDINGS(fractal_gas) {
  emscripten::value_object<FgParams>("FgParams")
      .field("n", &FgParams::n)
      .field("distCoef", &FgParams::distCoef)
      .field("rewardCoef", &FgParams::rewardCoef)
      .field("useCumulativeReward", &FgParams::useCumulativeReward)
      .field("dtMin", &FgParams::dtMin)
      .field("dtMax", &FgParams::dtMax)
      .field("nElite", &FgParams::nElite)
      .field("seed", &FgParams::seed)
      .field("nThreads", &FgParams::nThreads)
      .field("memoryLimitBytes", &FgParams::memoryLimitBytes)
      .field("obsMode", &FgParams::obsMode)
      .field("world", &FgParams::world)
      .field("stage", &FgParams::stage)
      .field("console", &FgParams::console)
      .field("game", &FgParams::game)
      .field("algorithm", &FgParams::algorithm)
      .field("horizon", &FgParams::horizon)
      .field("consensusPrefix", &FgParams::consensusPrefix)
      .field("maxHorizon", &FgParams::maxHorizon)
      .field("maxWalkers", &FgParams::maxWalkers)
      .field("freezePrefixAfter", &FgParams::freezePrefixAfter)
      .field("eraseCoef", &FgParams::eraseCoef)
      .field("aggBlock", &FgParams::aggBlock)
      .field("visitReward", &FgParams::visitReward)
      .field("visitCoef", &FgParams::visitCoef)
      .field("farmPtr", &FgParams::farmPtr)
      .field("farmWorkers", &FgParams::farmWorkers)
      .field("farmBlobLen", &FgParams::farmBlobLen);

  emscripten::function("init", &fg_init);
  emscripten::function("lastError", &fg_last_error);
  emscripten::function("algorithm", &fg_algorithm);
  emscripten::function("maxWalkers", &fg_max_walkers);
  emscripten::function("populationStatus", &fg_population_status);
  emscripten::function("setPopulation", &fg_set_population);
  emscripten::function("step", &fg_step);
  emscripten::function("getBestFrame", &fg_get_best_frame);
  emscripten::function("renderWalkerFrame", &fg_render_walker_frame);
  emscripten::function("selectTrajectory", &fg_select_trajectory);
  emscripten::function("trajectoryFrame", &fg_trajectory_frame);
  emscripten::function("getWalkerTiles", &fg_get_walker_tiles);
  emscripten::function("countingVisits", &fg_counting_visits);
  emscripten::function("getVisitBlocks", &fg_get_visit_blocks);
  emscripten::function("frameWidth", &fg_frame_width);
  emscripten::function("frameHeight", &fg_frame_height);
  emscripten::function("nActions", &fg_n_actions);
  emscripten::function("setDistanceMetric", +[](std::string name) {
    const auto metric = fg::parse_distance_metric(name);
    if (g_algo) g_algo->set_distance_metric(metric);
  });
  emscripten::function("setParams", &fg_set_params);
  emscripten::function("setRewardWeights", &fg_set_reward_weights);
  emscripten::function("reset", &fg_reset);
}

#endif  // __EMSCRIPTEN__
